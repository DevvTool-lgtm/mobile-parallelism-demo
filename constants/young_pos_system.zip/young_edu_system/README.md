# Young POS System - Modern Business Management Solution

A comprehensive, modern Point of Sale (POS) and business management system with a stunning user interface, complete CRUD functionality, and advanced features.

## Features

### 🎨 Modern UI/UX Design
- **Glowing Effects**: Beautiful animated polygon backgrounds with glowing buttons
- **Responsive Design**: Fully responsive layout that works on all devices
- **Modern Transitions**: Smooth animations and micro-interactions
- **Professional Theme**: Dark theme with gradient accents
- **Interactive Elements**: Hover effects, loading states, and animated modals

### 📋 Complete CRUD Operations
- **Invoices**: Full invoice management with item details
- **Clients**: Customer relationship management
- **Products**: Inventory management system
- **Suppliers**: Supplier management
- **Sales**: Sales tracking and reporting
- **Users**: User management (Admin only)
- **Employees**: Employee management (Admin only)

### 🔐 Security & Authentication
- **Role-based Access**: Admin, Staff, Manager roles
- **Secure Login**: Password hashing and session management
- **Session Protection**: Secure session handling
- **Access Control**: Page-level permission system

### 📊 Dashboard & Analytics
- **Real-time Statistics**: Live dashboard with key metrics
- **Recent Activity**: Track recent invoices and transactions
- **Visual Analytics**: Beautiful charts and graphs
- **Quick Actions**: Fast access to common tasks

### 🛠 Technical Features
- **PHP 8.2+**: Modern PHP with PDO database connections
- **MySQL Database**: Optimized database design with proper relationships
- **AJAX Interactions**: Dynamic content loading without page refresh
- **Form Validation**: Client-side and server-side validation
- **Error Handling**: Comprehensive error reporting and logging
- **Auto-save**: Automatic form data saving
- **Export Features**: CSV export for reports

## Installation

### Prerequisites
- XAMPP/WAMP/MAMP (Apache + MySQL + PHP)
- PHP 8.0 or higher
- MySQL 5.7 or higher
- Modern web browser

### Setup Instructions

1. **Download and Extract**
   - Download the system package
   - Extract to your web server directory (e.g., `htdocs/young_pos_system`)

2. **Database Setup**
   - Start Apache and MySQL in XAMPP
   - Open phpMyAdmin (http://localhost/phpmyadmin)
   - Create a new database named `young_pos_system`
   - Import the `young_edu_unified.sql` file

3. **Configuration**
   - The system is pre-configured for XAMPP
   - Database settings are in `config/database.php`
   - Default connection: `localhost` with `root` user and no password

4. **Access the System**
   - Open your browser and go to: `http://localhost/young_pos_system`
   - Default login credentials:
     - Username: `admin`
     - Password: `password`

## File Structure

```
young_edu_system/
├── assets/
│   ├── css/
│   │   └── modern.css          # Modern styling with glowing effects
│   ├── js/
│   │   └── main.js             # Interactive JavaScript functionality
│   ├── images/
│   └── fonts/
├── classes/
│   ├── Auth.php                # Authentication class
│   ├── Invoice.php             # Invoice management class
│   └── [Other model classes]
├── config/
│   └── database.php            # Database configuration
├── includes/
│   └── sidebar.php             # Navigation sidebar
├── pages/
│   ├── dashboard.php           # Main dashboard
│   ├── invoices.php            # Invoice management
│   ├── clients.php             # Client management
│   ├── products.php            # Product management
│   ├── [Other pages]
├── login.php                   # Login page
├── logout.php                  # Logout handler
├── index.php                   # Redirect to login
└── README.md                   # This file
```

## Database Schema

The system uses a unified database with the following main tables:

- **users**: System users with role-based access
- **clients**: Customer information
- **suppliers**: Supplier details
- **products**: Product inventory
- **invoices**: Invoice management
- **invoice_items**: Invoice line items
- **sales**: Sales transactions
- **employees**: Employee records
- **inventory**: Stock movements

## User Roles

### Admin
- Full system access
- User management
- System configuration
- All CRUD operations

### Manager
- Invoice management
- Client and supplier management
- Sales reporting
- Product management

### Staff
- Create and edit invoices
- View reports
- Limited product management

## Customization

### Colors and Theme
Edit the CSS variables in `assets/css/modern.css`:

```css
:root {
    --primary-color: #667eea;
    --secondary-color: #764ba2;
    --accent-color: #f093fb;
    --dark-bg: #0f0f1e;
    /* ... more variables */
}
```

### Logo and Branding
Update the logo in `includes/sidebar.php`:

```php
<div class="logo">Your Brand Name</div>
```

### Database Configuration
Modify database settings in `config/database.php`:

```php
private $host = "localhost";
private $db_name = "your_database_name";
private $username = "your_username";
private $password = "your_password";
```

## Features Implementation Status

### ✅ Completed Features
- [x] Modern UI with glowing effects
- [x] Authentication system
- [x] Dashboard with statistics
- [x] Invoice management interface
- [x] Responsive design
- [x] Modal dialogs
- [x] Form validation
- [x] Database structure

### 🚧 Features to Implement
- [ ] Full CRUD for clients
- [ ] Full CRUD for products
- [ ] Supplier management
- [ ] Sales tracking
- [ ] Reports and analytics
- [ ] User management (Admin only)
- [ ] Employee management
- [ ] Export functionality
- [ ] Advanced search
- [ ] Print invoices
- [ ] Email notifications

## Security Considerations

- All passwords are hashed using PHP's `password_hash()`
- SQL injection prevention with prepared statements
- XSS protection with output escaping
- Session security with proper configuration
- Input validation and sanitization

## Browser Support

- Chrome 90+
- Firefox 88+
- Safari 14+
- Edge 90+

## Support

For support and updates, please refer to the documentation or contact the development team.

## License

This system is developed for internal business use. All rights reserved.

---

**Note**: This is a modern, feature-rich POS system designed with the latest web technologies. The interface includes advanced CSS animations, glowing effects, and a professional design that provides an excellent user experience.