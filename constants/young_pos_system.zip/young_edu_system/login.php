<?php
session_start();
require_once 'classes/Auth.php';

$auth = new Auth();

if ($auth->isLoggedIn()) {
    header("Location: pages/dashboard.php");
    exit();
}

$error = '';

if ($_POST) {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    
    if ($auth->login($username, $password)) {
        header("Location: pages/dashboard.php");
        exit();
    } else {
        $error = "Invalid username or password";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Young POS System</title>
    <link rel="stylesheet" href="assets/css/modern.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
</head>
<body>
    <div class="bg-animation">
        <div class="polygon polygon1"></div>
        <div class="polygon polygon2"></div>
        <div class="polygon polygon3"></div>
    </div>
    
    <div class="login-container">
        <div class="login-card">
            <div class="text-center mb-4">
                <h1 style="font-size: 32px; font-weight: 800; background: linear-gradient(135deg, #667eea, #f093fb); -webkit-background-clip: text; -webkit-text-fill-color: transparent; margin-bottom: 8px;">
                    Young POS System
                </h1>
                <p style="color: var(--text-secondary); font-size: 16px;">
                    Modern Business Management Solution
                </p>
            </div>
            
            <?php if ($error): ?>
                <div class="alert alert-danger">
                    <svg width="20" height="20" fill="currentColor" viewBox="0 0 20 20">
                        <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd"/>
                    </svg>
                    <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>
            
            <form method="POST" action="" style="margin-top: 30px;">
                <div class="form-group">
                    <label class="form-label" for="username">Username</label>
                    <input type="text" class="form-control" id="username" name="username" 
                           placeholder="Enter your username" required 
                           style="background-image: url('data:image/svg+xml,<svg xmlns=&quot;http://www.w3.org/2000/svg&quot; width=&quot;20&quot; height=&quot;20&quot; fill=&quot;%23a0a0a0&quot; viewBox=&quot;0 0 20 20&quot;><path fill-rule=&quot;evenodd&quot; d=&quot;M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z&quot; clip-rule=&quot;evenodd&quot;/></svg>'); background-repeat: no-repeat; background-position: right 12px center; background-size: 20px;">
                </div>
                
                <div class="form-group">
                    <label class="form-label" for="password">Password</label>
                    <input type="password" class="form-control" id="password" name="password" 
                           placeholder="Enter your password" required
                           style="background-image: url('data:image/svg+xml,<svg xmlns=&quot;http://www.w3.org/2000/svg&quot; width=&quot;20&quot; height=&quot;20&quot; fill=&quot;%23a0a0a0&quot; viewBox=&quot;0 0 20 20&quot;><path fill-rule=&quot;evenodd&quot; d=&quot;M5 9V7a5 5 0 0110 0v2a2 2 0 012 2v5a2 2 0 01-2 2H5a2 2 0 01-2-2v-5a2 2 0 012-2zm8-2v2H7V7a3 3 0 016 0z&quot; clip-rule=&quot;evenodd&quot;/></svg>'); background-repeat: no-repeat; background-position: right 12px center; background-size: 20px;">
                </div>
                
                <div class="form-group mb-4">
                    <label style="display: flex; align-items: center; gap: 8px; cursor: pointer;">
                        <input type="checkbox" style="width: 18px; height: 18px; accent-color: var(--primary-color);">
                        <span style="color: var(--text-secondary); font-size: 14px;">Remember me</span>
                    </label>
                </div>
                
                <button type="submit" class="btn btn-primary" style="width: 100%; font-size: 18px; padding: 14px; margin-bottom: 20px;">
                    Sign In
                </button>
                
                <div style="text-align: center; color: var(--text-secondary); font-size: 14px;">
                    <p>Default Credentials:</p>
                    <p style="font-family: monospace; background: rgba(255,255,255,0.05); padding: 8px; border-radius: 8px; margin-top: 8px;">
                        Username: admin | Password: password
                    </p>
                </div>
            </form>
        </div>
    </div>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const form = document.querySelector('form');
            const inputs = document.querySelectorAll('.form-control');
            
            inputs.forEach(input => {
                input.addEventListener('focus', function() {
                    this.parentElement.style.transform = 'scale(1.02)';
                });
                
                input.addEventListener('blur', function() {
                    this.parentElement.style.transform = 'scale(1)';
                });
            });
            
            form.addEventListener('submit', function() {
                const submitBtn = this.querySelector('button[type="submit"]');
                submitBtn.innerHTML = '<span class="spinner" style="width: 20px; height: 20px; border-width: 2px; margin-right: 8px;"></span> Signing in...';
                submitBtn.disabled = true;
            });
        });
    </script>
</body>
</html>