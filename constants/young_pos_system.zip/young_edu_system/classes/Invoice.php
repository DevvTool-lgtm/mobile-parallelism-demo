<?php
require_once __DIR__ . '/../config/database.php';

class Invoice {
    private $conn;
    
    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }
    
    public function getAllInvoices() {
        $query = "SELECT i.*, c.first_name, c.last_name, s.company_name as supplier_name, u.username as created_by_name 
                 FROM invoices i 
                 LEFT JOIN clients c ON i.client_id = c.id 
                 LEFT JOIN suppliers s ON i.supplier_id = s.id 
                 LEFT JOIN users u ON i.created_by = u.id 
                 ORDER BY i.created_at DESC";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll();
    }
    
    public function getInvoiceById($id) {
        $query = "SELECT i.*, c.first_name, c.last_name, s.company_name as supplier_name, u.username as created_by_name 
                 FROM invoices i 
                 LEFT JOIN clients c ON i.client_id = c.id 
                 LEFT JOIN suppliers s ON i.supplier_id = s.id 
                 LEFT JOIN users u ON i.created_by = u.id 
                 WHERE i.id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        return $stmt->fetch();
    }
    
    public function getInvoiceItems($invoice_id) {
        $query = "SELECT ii.*, p.product_name, p.barcode 
                 FROM invoice_items ii 
                 LEFT JOIN products p ON ii.product_id = p.id 
                 WHERE ii.invoice_id = :invoice_id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':invoice_id', $invoice_id);
        $stmt->execute();
        return $stmt->fetchAll();
    }
    
    public function createInvoice($data) {
        try {
            $this->conn->beginTransaction();
            
            $query = "INSERT INTO invoices (invoice_no, transaction_date, client_id, supplier_id, subtotal, tax_amount, total_amount, payment_status, payment_method, notes, created_by) 
                     VALUES (:invoice_no, :transaction_date, :client_id, :supplier_id, :subtotal, :tax_amount, :total_amount, :payment_status, :payment_method, :notes, :created_by)";
            $stmt = $this->conn->prepare($query);
            
            $stmt->bindParam(':invoice_no', $data['invoice_no']);
            $stmt->bindParam(':transaction_date', $data['transaction_date']);
            $stmt->bindParam(':client_id', $data['client_id']);
            $stmt->bindParam(':supplier_id', $data['supplier_id']);
            $stmt->bindParam(':subtotal', $data['subtotal']);
            $stmt->bindParam(':tax_amount', $data['tax_amount']);
            $stmt->bindParam(':total_amount', $data['total_amount']);
            $stmt->bindParam(':payment_status', $data['payment_status']);
            $stmt->bindParam(':payment_method', $data['payment_method']);
            $stmt->bindParam(':notes', $data['notes']);
            $stmt->bindParam(':created_by', $data['created_by']);
            
            $stmt->execute();
            $invoice_id = $this->conn->lastInsertId();
            
            foreach ($data['items'] as $item) {
                $item_query = "INSERT INTO invoice_items (invoice_id, product_id, quantity, unit_price, total_price) 
                              VALUES (:invoice_id, :product_id, :quantity, :unit_price, :total_price)";
                $item_stmt = $this->conn->prepare($item_query);
                
                $item_stmt->bindParam(':invoice_id', $invoice_id);
                $item_stmt->bindParam(':product_id', $item['product_id']);
                $item_stmt->bindParam(':quantity', $item['quantity']);
                $item_stmt->bindParam(':unit_price', $item['unit_price']);
                $item_stmt->bindParam(':total_price', $item['total_price']);
                
                $item_stmt->execute();
            }
            
            $this->conn->commit();
            return $invoice_id;
        } catch (Exception $e) {
            $this->conn->rollback();
            throw $e;
        }
    }
    
    public function updateInvoice($id, $data) {
        try {
            $this->conn->beginTransaction();
            
            $query = "UPDATE invoices SET 
                     transaction_date = :transaction_date, 
                     client_id = :client_id, 
                     supplier_id = :supplier_id, 
                     subtotal = :subtotal, 
                     tax_amount = :tax_amount, 
                     total_amount = :total_amount, 
                     payment_status = :payment_status, 
                     payment_method = :payment_method, 
                     notes = :notes 
                     WHERE id = :id";
            $stmt = $this->conn->prepare($query);
            
            $stmt->bindParam(':id', $id);
            $stmt->bindParam(':transaction_date', $data['transaction_date']);
            $stmt->bindParam(':client_id', $data['client_id']);
            $stmt->bindParam(':supplier_id', $data['supplier_id']);
            $stmt->bindParam(':subtotal', $data['subtotal']);
            $stmt->bindParam(':tax_amount', $data['tax_amount']);
            $stmt->bindParam(':total_amount', $data['total_amount']);
            $stmt->bindParam(':payment_status', $data['payment_status']);
            $stmt->bindParam(':payment_method', $data['payment_method']);
            $stmt->bindParam(':notes', $data['notes']);
            
            $stmt->execute();
            
            $delete_items = "DELETE FROM invoice_items WHERE invoice_id = :invoice_id";
            $delete_stmt = $this->conn->prepare($delete_items);
            $delete_stmt->bindParam(':invoice_id', $id);
            $delete_stmt->execute();
            
            foreach ($data['items'] as $item) {
                $item_query = "INSERT INTO invoice_items (invoice_id, product_id, quantity, unit_price, total_price) 
                              VALUES (:invoice_id, :product_id, :quantity, :unit_price, :total_price)";
                $item_stmt = $this->conn->prepare($item_query);
                
                $item_stmt->bindParam(':invoice_id', $id);
                $item_stmt->bindParam(':product_id', $item['product_id']);
                $item_stmt->bindParam(':quantity', $item['quantity']);
                $item_stmt->bindParam(':unit_price', $item['unit_price']);
                $item_stmt->bindParam(':total_price', $item['total_price']);
                
                $item_stmt->execute();
            }
            
            $this->conn->commit();
            return true;
        } catch (Exception $e) {
            $this->conn->rollback();
            throw $e;
        }
    }
    
    public function deleteInvoice($id) {
        try {
            $this->conn->beginTransaction();
            
            $delete_items = "DELETE FROM invoice_items WHERE invoice_id = :invoice_id";
            $delete_stmt = $this->conn->prepare($delete_items);
            $delete_stmt->bindParam(':invoice_id', $id);
            $delete_stmt->execute();
            
            $query = "DELETE FROM invoices WHERE id = :id";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':id', $id);
            $stmt->execute();
            
            $this->conn->commit();
            return true;
        } catch (Exception $e) {
            $this->conn->rollback();
            throw $e;
        }
    }
    
    public function generateInvoiceNumber() {
        $query = "SELECT COUNT(*) as count FROM invoices WHERE DATE(created_at) = CURDATE()";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        $result = $stmt->fetch();
        $count = $result['count'] + 1;
        
        $date = date('Ymd');
        return "INV" . $date . str_pad($count, 3, '0', STR_PAD_LEFT);
    }
}
?>