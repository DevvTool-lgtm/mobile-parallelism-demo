<?php
require_once '../classes/Auth.php';
require_once '../classes/Invoice.php';

$auth = new Auth();
$auth->requireLogin();

$invoice = new Invoice();
$invoices = $invoice->getAllInvoices();

$action = $_GET['action'] ?? '';
$id = $_GET['id'] ?? '';

if ($action === 'delete' && $id) {
    try {
        $invoice->deleteInvoice($id);
        $success = "Invoice deleted successfully!";
    } catch (Exception $e) {
        $error = "Error deleting invoice: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Invoices - Young POS System</title>
    <link rel="stylesheet" href="../assets/css/modern.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
</head>
<body>
    <div class="bg-animation">
        <div class="polygon polygon1"></div>
        <div class="polygon polygon2"></div>
        <div class="polygon polygon3"></div>
    </div>
    
    <div class="dashboard-container">
        <?php include '../includes/sidebar.php'; ?>
        
        <main class="main-content">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 32px;">
                <div>
                    <h1 style="font-size: 32px; font-weight: 800; color: var(--text-primary); margin-bottom: 8px;">
                        Invoices
                    </h1>
                    <p style="color: var(--text-secondary); font-size: 16px;">
                        Manage your invoices and billing
                    </p>
                </div>
                
                <button onclick="openInvoiceModal()" class="btn btn-primary">
                    <svg width="20" height="20" fill="currentColor" viewBox="0 0 20 20" style="margin-right: 8px;">
                        <path fill-rule="evenodd" d="M10 3a1 1 0 011 1v5h5a1 1 0 110 2h-5v5a1 1 0 11-2 0v-5H4a1 1 0 110-2h5V4a1 1 0 011-1z" clip-rule="evenodd"/>
                    </svg>
                    New Invoice
                </button>
            </div>
            
            <?php if (isset($success)): ?>
                <div class="alert alert-success">
                    <svg width="20" height="20" fill="currentColor" viewBox="0 0 20 20">
                        <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/>
                    </svg>
                    <?php echo htmlspecialchars($success); ?>
                </div>
            <?php endif; ?>
            
            <?php if (isset($error)): ?>
                <div class="alert alert-danger">
                    <svg width="20" height="20" fill="currentColor" viewBox="0 0 20 20">
                        <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd"/>
                    </svg>
                    <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>
            
            <div class="table-container">
                <table class="modern-table">
                    <thead>
                        <tr>
                            <th>Invoice No.</th>
                            <th>Client</th>
                            <th>Supplier</th>
                            <th>Date</th>
                            <th>Total Amount</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($invoices)): ?>
                            <tr>
                                <td colspan="7" style="text-align: center; padding: 40px; color: var(--text-secondary);">
                                    No invoices found. 
                                    <button onclick="openInvoiceModal()" class="btn btn-primary btn-sm" style="margin-left: 16px;">
                                        Create First Invoice
                                    </button>
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($invoices as $inv): ?>
                                <tr>
                                    <td style="font-weight: 600; color: var(--primary-color);">
                                        <?php echo htmlspecialchars($inv['invoice_no']); ?>
                                    </td>
                                    <td>
                                        <?php echo htmlspecialchars($inv['first_name'] . ' ' . $inv['last_name']); ?>
                                    </td>
                                    <td>
                                        <?php echo htmlspecialchars($inv['supplier_name'] ?: 'N/A'); ?>
                                    </td>
                                    <td>
                                        <?php echo date('M d, Y', strtotime($inv['transaction_date'])); ?>
                                    </td>
                                    <td style="font-weight: 600;">
                                        ₱<?php echo number_format($inv['total_amount'], 2); ?>
                                    </td>
                                    <td>
                                        <span class="btn btn-<?php 
                                            echo $inv['payment_status'] == 'Paid' ? 'success' : 
                                                 ($inv['payment_status'] == 'Partial' ? 'warning' : 'danger'); 
                                        ?> btn-sm">
                                            <?php echo htmlspecialchars($inv['payment_status']); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <div class="action-buttons">
                                            <button onclick="viewInvoice(<?php echo $inv['id']; ?>)" class="btn btn-primary btn-icon btn-sm">
                                                <svg width="16" height="16" fill="currentColor" viewBox="0 0 20 20">
                                                    <path d="M10 12a2 2 0 100-4 2 2 0 000 4z"/>
                                                    <path fill-rule="evenodd" d="M.458 10C1.732 5.943 5.522 3 10 3s8.268 2.943 9.542 7c-1.274 4.057-5.064 7-9.542 7S1.732 14.057.458 10zM14 10a4 4 0 11-8 0 4 4 0 018 0z" clip-rule="evenodd"/>
                                                </svg>
                                                View
                                            </button>
                                            <button onclick="editInvoice(<?php echo $inv['id']; ?>)" class="btn btn-warning btn-icon btn-sm">
                                                <svg width="16" height="16" fill="currentColor" viewBox="0 0 20 20">
                                                    <path d="M13.586 3.586a2 2 0 112.828 2.828l-.793.793-2.828-2.828.793-.793zM11.379 5.793L3 14.172V17h2.828l8.38-8.379-2.83-2.828z"/>
                                                </svg>
                                                Edit
                                            </button>
                                            <button onclick="deleteInvoice(<?php echo $inv['id']; ?>)" class="btn btn-danger btn-icon btn-sm">
                                                <svg width="16" height="16" fill="currentColor" viewBox="0 0 20 20">
                                                    <path fill-rule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v6a1 1 0 102 0V8a1 1 0 00-1-1z" clip-rule="evenodd"/>
                                                </svg>
                                                Delete
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </main>
    </div>
    
    <!-- Invoice Modal -->
    <div id="invoiceModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="modal-title" id="modalTitle">New Invoice</h2>
                <button class="close-btn" onclick="closeInvoiceModal()">&times;</button>
            </div>
            <div class="modal-body">
                <form id="invoiceForm">
                    <input type="hidden" id="invoiceId" name="id">
                    
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-bottom: 20px;">
                        <div class="form-group">
                            <label class="form-label">Invoice Number</label>
                            <input type="text" class="form-control" id="invoiceNo" name="invoice_no" readonly>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Transaction Date</label>
                            <input type="date" class="form-control" id="transactionDate" name="transaction_date" required>
                        </div>
                    </div>
                    
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-bottom: 20px;">
                        <div class="form-group">
                            <label class="form-label">Client</label>
                            <select class="form-control" id="clientId" name="client_id">
                                <option value="">Select Client</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Payment Method</label>
                            <select class="form-control" id="paymentMethod" name="payment_method">
                                <option value="Cash">Cash</option>
                                <option value="Credit">Credit</option>
                                <option value="Bank Transfer">Bank Transfer</option>
                                <option value="Check">Check</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="form-group" style="margin-bottom: 20px;">
                        <label class="form-label">Notes</label>
                        <textarea class="form-control" id="notes" name="notes" rows="3"></textarea>
                    </div>
                    
                    <div class="form-group" style="margin-bottom: 20px;">
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px;">
                            <label class="form-label">Invoice Items</label>
                            <button type="button" onclick="addInvoiceItem()" class="btn btn-primary btn-sm">
                                <svg width="16" height="16" fill="currentColor" viewBox="0 0 20 20" style="margin-right: 6px;">
                                    <path fill-rule="evenodd" d="M10 3a1 1 0 011 1v5h5a1 1 0 110 2h-5v5a1 1 0 11-2 0v-5H4a1 1 0 110-2h5V4a1 1 0 011-1z" clip-rule="evenodd"/>
                                </svg>
                                Add Item
                            </button>
                        </div>
                        <div id="invoiceItems">
                            <!-- Invoice items will be added here dynamically -->
                        </div>
                    </div>
                    
                    <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 16px; padding: 20px; background: rgba(102, 126, 234, 0.1); border-radius: 12px;">
                        <div>
                            <label class="form-label">Subtotal</label>
                            <input type="number" class="form-control" id="subtotal" name="subtotal" readonly>
                        </div>
                        <div>
                            <label class="form-label">Tax (12%)</label>
                            <input type="number" class="form-control" id="taxAmount" name="tax_amount" readonly>
                        </div>
                        <div>
                            <label class="form-label">Total Amount</label>
                            <input type="number" class="form-control" id="totalAmount" name="total_amount" readonly>
                        </div>
                    </div>
                    
                    <div style="display: flex; gap: 12px; margin-top: 24px;">
                        <button type="submit" class="btn btn-primary" style="flex: 1;">
                            Save Invoice
                        </button>
                        <button type="button" onclick="closeInvoiceModal()" class="btn btn-danger" style="flex: 1;">
                            Cancel
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <script src="../assets/js/main.js"></script>
    <script>
        let invoiceItems = [];
        
        document.addEventListener('DOMContentLoaded', function() {
            document.getElementById('transactionDate').value = new Date().toISOString().split('T')[0];
            loadClients();
            loadProducts();
        });
        
        function openInvoiceModal(invoiceId = null) {
            const modal = document.getElementById('invoiceModal');
            const title = document.getElementById('modalTitle');
            
            if (invoiceId) {
                title.textContent = 'Edit Invoice';
                loadInvoice(invoiceId);
            } else {
                title.textContent = 'New Invoice';
                document.getElementById('invoiceForm').reset();
                document.getElementById('invoiceNo').value = generateInvoiceNumber();
                document.getElementById('transactionDate').value = new Date().toISOString().split('T')[0];
                invoiceItems = [];
                renderInvoiceItems();
            }
            
            modal.classList.add('active');
        }
        
        function closeInvoiceModal() {
            document.getElementById('invoiceModal').classList.remove('active');
        }
        
        function generateInvoiceNumber() {
            const date = new Date();
            const dateStr = date.toISOString().slice(0, 10).replace(/-/g, '');
            const random = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
            return 'INV' + dateStr + random;
        }
        
        function addInvoiceItem() {
            const item = {
                id: Date.now(),
                product_id: '',
                product_name: '',
                quantity: 1,
                unit_price: 0,
                total_price: 0
            };
            invoiceItems.push(item);
            renderInvoiceItems();
        }
        
        function renderInvoiceItems() {
            const container = document.getElementById('invoiceItems');
            container.innerHTML = '';
            
            if (invoiceItems.length === 0) {
                container.innerHTML = '<p style="text-align: center; color: var(--text-secondary); padding: 20px;">No items added. Click "Add Item" to add products.</p>';
                return;
            }
            
            invoiceItems.forEach((item, index) => {
                const itemHtml = `
                    <div style="display: grid; grid-template-columns: 2fr 1fr 1fr 1fr auto; gap: 12px; padding: 16px; background: rgba(255, 255, 255, 0.05); border-radius: 12px; margin-bottom: 12px;">
                        <select class="form-control" onchange="updateItemProduct(${index}, this.value)" required>
                            <option value="">Select Product</option>
                        </select>
                        <input type="number" class="form-control" placeholder="Quantity" value="${item.quantity}" 
                               onchange="updateItemQuantity(${index}, this.value)" min="1" required>
                        <input type="number" class="form-control" placeholder="Price" value="${item.unit_price}" 
                               onchange="updateItemPrice(${index}, this.value)" min="0" step="0.01" required>
                        <input type="number" class="form-control" value="${item.total_price}" readonly>
                        <button type="button" onclick="removeInvoiceItem(${index})" class="btn btn-danger btn-sm">
                            <svg width="16" height="16" fill="currentColor" viewBox="0 0 20 20">
                                <path fill-rule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clip-rule="evenodd"/>
                            </svg>
                        </button>
                    </div>
                `;
                container.innerHTML += itemHtml;
            });
            
            loadProducts();
            calculateTotals();
        }
        
        function updateItemProduct(index, productId) {
            // Update product and price based on selection
            calculateTotals();
        }
        
        function updateItemQuantity(index, quantity) {
            invoiceItems[index].quantity = parseInt(quantity);
            calculateTotals();
        }
        
        function updateItemPrice(index, price) {
            invoiceItems[index].unit_price = parseFloat(price);
            calculateTotals();
        }
        
        function calculateTotals() {
            let subtotal = 0;
            invoiceItems.forEach(item => {
                item.total_price = item.quantity * item.unit_price;
                subtotal += item.total_price;
            });
            
            const taxAmount = subtotal * 0.12;
            const totalAmount = subtotal + taxAmount;
            
            document.getElementById('subtotal').value = subtotal.toFixed(2);
            document.getElementById('taxAmount').value = taxAmount.toFixed(2);
            document.getElementById('totalAmount').value = totalAmount.toFixed(2);
        }
        
        function removeInvoiceItem(index) {
            invoiceItems.splice(index, 1);
            renderInvoiceItems();
        }
        
        function viewInvoice(id) {
            // Implement view functionality
            alert('View invoice functionality would open invoice details');
        }
        
        function editInvoice(id) {
            openInvoiceModal(id);
        }
        
        function deleteInvoice(id) {
            if (confirm('Are you sure you want to delete this invoice?')) {
                window.location.href = 'invoices.php?action=delete&id=' + id;
            }
        }
        
        function loadClients() {
            // Load clients from database
            // This is a placeholder - implement actual API call
        }
        
        function loadProducts() {
            // Load products from database
            // This is a placeholder - implement actual API call
        }
        
        // Close modal when clicking outside
        window.onclick = function(event) {
            const modal = document.getElementById('invoiceModal');
            if (event.target === modal) {
                closeInvoiceModal();
            }
        }
    </script>
</body>
</html>