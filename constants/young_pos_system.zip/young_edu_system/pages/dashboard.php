<?php
require_once '../classes/Auth.php';
require_once '../classes/Invoice.php';
require_once '../config/database.php';

$auth = new Auth();
$auth->requireLogin();

$invoice = new Invoice();
$currentUser = $auth->getCurrentUser();

$stats = [
    'total_invoices' => 0,
    'total_sales' => 0,
    'pending_payments' => 0,
    'today_invoices' => 0
];

try {
    $conn = (new Database())->getConnection();
    
    $stmt = $conn->query("SELECT COUNT(*) as count FROM invoices");
    $stats['total_invoices'] = $stmt->fetch()['count'];
    
    $stmt = $conn->query("SELECT COALESCE(SUM(total_amount), 0) as total FROM invoices WHERE payment_status = 'Paid'");
    $stats['total_sales'] = $stmt->fetch()['total'];
    
    $stmt = $conn->query("SELECT COUNT(*) as count FROM invoices WHERE payment_status = 'Unpaid'");
    $stats['pending_payments'] = $stmt->fetch()['count'];
    
    $stmt = $conn->query("SELECT COUNT(*) as count FROM invoices WHERE DATE(created_at) = CURDATE()");
    $stats['today_invoices'] = $stmt->fetch()['count'];
} catch (Exception $e) {
    error_log("Stats error: " . $e->getMessage());
}

$recentInvoices = $invoice->getAllInvoices();
$recentInvoices = array_slice($recentInvoices, 0, 5);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Young POS System</title>
    <link rel="stylesheet" href="../assets/css/modern.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 24px;
            margin-bottom: 32px;
        }
        
        .stat-card {
            background: var(--card-bg);
            backdrop-filter: blur(20px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 16px;
            padding: 24px;
            position: relative;
            overflow: hidden;
            transition: var(--transition-smooth);
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.3);
        }
        
        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 3px;
            background: linear-gradient(90deg, var(--primary-color), var(--accent-color));
        }
        
        .stat-icon {
            width: 60px;
            height: 60px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            margin-bottom: 16px;
        }
        
        .stat-value {
            font-size: 32px;
            font-weight: 800;
            color: var(--text-primary);
            margin-bottom: 8px;
        }
        
        .stat-label {
            color: var(--text-secondary);
            font-size: 14px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .recent-activity {
            background: var(--card-bg);
            backdrop-filter: blur(20px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 16px;
            padding: 24px;
        }
        
        .activity-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 16px 0;
            border-bottom: 1px solid rgba(255, 255, 255, 0.05);
            transition: var(--transition-smooth);
        }
        
        .activity-item:hover {
            background: rgba(102, 126, 234, 0.05);
            margin: 0 -16px;
            padding-left: 16px;
            padding-right: 16px;
            border-radius: 8px;
        }
        
        .activity-item:last-child {
            border-bottom: none;
        }
    </style>
</head>
<body>
    <div class="bg-animation">
        <div class="polygon polygon1"></div>
        <div class="polygon polygon2"></div>
        <div class="polygon polygon3"></div>
    </div>
    
    <div class="dashboard-container">
        <?php include '../includes/sidebar.php'; ?>
        
        <main class="main-content">
            <div style="margin-bottom: 32px;">
                <h1 style="font-size: 32px; font-weight: 800; color: var(--text-primary); margin-bottom: 8px;">
                    Dashboard
                </h1>
                <p style="color: var(--text-secondary); font-size: 16px;">
                    Welcome back, <span style="color: var(--primary-color); font-weight: 600;"><?php echo htmlspecialchars($currentUser['username']); ?></span>
                </p>
            </div>
            
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-icon" style="background: linear-gradient(135deg, #667eea, #764ba2);">
                        <svg width="24" height="24" fill="white" viewBox="0 0 20 20">
                            <path d="M9 2a1 1 0 000 2h2a1 1 0 100-2H9z"/>
                            <path fill-rule="evenodd" d="M4 5a2 2 0 012-2 1 1 0 000 2H6a2 2 0 100 4h2a2 2 0 100 4h2a1 1 0 100 2 2 2 0 01-2 2H6a2 2 0 01-2-2V5z" clip-rule="evenodd"/>
                        </svg>
                    </div>
                    <div class="stat-value"><?php echo number_format($stats['total_invoices']); ?></div>
                    <div class="stat-label">Total Invoices</div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon" style="background: linear-gradient(135deg, #10b981, #059669);">
                        <svg width="24" height="24" fill="white" viewBox="0 0 20 20">
                            <path d="M8.433 7.418c.155-.103.346-.196.567-.267v1.698a2.305 2.305 0 01-.567-.267C8.07 8.34 8 8.114 8 8c0-.114.07-.34.433-.582zM11 12.849v-1.698c.22.071.412.164.567.267.364.243.433.468.433.582 0 .114-.07.34-.433.582a2.305 2.305 0 01-.567.267z"/>
                            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-13a1 1 0 10-2 0v.092a4.535 4.535 0 00-1.676.662C6.602 6.234 6 7.009 6 8c0 .99.602 1.765 1.324 2.246.48.32 1.054.545 1.676.662v1.941c-.391-.127-.68-.317-.843-.504a1 1 0 10-1.51 1.31c.562.649 1.413 1.076 2.353 1.253V15a1 1 0 102 0v-.092a4.535 4.535 0 001.676-.662C13.398 13.766 14 12.991 14 12c0-.99-.602-1.765-1.324-2.246A4.535 4.535 0 0011 9.092V7.151c.391.127.68.317.843.504a1 1 0 101.511-1.31c-.563-.649-1.413-1.076-2.354-1.253V5z" clip-rule="evenodd"/>
                        </svg>
                    </div>
                    <div class="stat-value">₱<?php echo number_format($stats['total_sales'], 2); ?></div>
                    <div class="stat-label">Total Sales</div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon" style="background: linear-gradient(135deg, #f59e0b, #d97706);">
                        <svg width="24" height="24" fill="white" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-12a1 1 0 10-2 0v4a1 1 0 00.293.707l2.828 2.829a1 1 0 101.415-1.415L11 9.586V6z" clip-rule="evenodd"/>
                        </svg>
                    </div>
                    <div class="stat-value"><?php echo number_format($stats['pending_payments']); ?></div>
                    <div class="stat-label">Pending Payments</div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon" style="background: linear-gradient(135deg, #f093fb, #f5576c);">
                        <svg width="24" height="24" fill="white" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M6 2a1 1 0 00-1 1v1H4a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V6a2 2 0 00-2-2h-1V3a1 1 0 10-2 0v1H7V3a1 1 0 00-1-1zm0 5a1 1 0 000 2h8a1 1 0 100-2H6z" clip-rule="evenodd"/>
                        </svg>
                    </div>
                    <div class="stat-value"><?php echo number_format($stats['today_invoices']); ?></div>
                    <div class="stat-label">Today's Invoices</div>
                </div>
            </div>
            
            <div class="recent-activity">
                <div class="card-header">
                    <h2 class="card-title">Recent Invoices</h2>
                    <a href="invoices.php" class="btn btn-primary btn-sm">View All</a>
                </div>
                
                <?php if (empty($recentInvoices)): ?>
                    <div style="text-align: center; padding: 40px; color: var(--text-secondary);">
                        <svg width="48" height="48" fill="currentColor" viewBox="0 0 20 20" style="margin: 0 auto 16px; opacity: 0.5;">
                            <path fill-rule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v6a1 1 0 102 0V8a1 1 0 00-1-1z" clip-rule="evenodd"/>
                        </svg>
                        <p>No invoices found</p>
                        <a href="invoices.php?action=add" class="btn btn-primary" style="margin-top: 16px;">Create First Invoice</a>
                    </div>
                <?php else: ?>
                    <div style="margin-top: 20px;">
                        <?php foreach ($recentInvoices as $inv): ?>
                            <div class="activity-item">
                                <div>
                                    <div style="font-weight: 600; color: var(--text-primary); margin-bottom: 4px;">
                                        <?php echo htmlspecialchars($inv['invoice_no']); ?>
                                    </div>
                                    <div style="font-size: 14px; color: var(--text-secondary);">
                                        <?php echo htmlspecialchars($inv['first_name'] . ' ' . $inv['last_name']); ?> • 
                                        <?php echo date('M d, Y', strtotime($inv['created_at'])); ?>
                                    </div>
                                </div>
                                <div style="text-align: right;">
                                    <div style="font-weight: 600; color: var(--text-primary); margin-bottom: 4px;">
                                        ₱<?php echo number_format($inv['total_amount'], 2); ?>
                                    </div>
                                    <span class="btn btn-<?php 
                                        echo $inv['payment_status'] == 'Paid' ? 'success' : 
                                             ($inv['payment_status'] == 'Partial' ? 'warning' : 'danger'); 
                                    ?> btn-sm" style="padding: 4px 8px; font-size: 11px;">
                                        <?php echo htmlspecialchars($inv['payment_status']); ?>
                                    </span>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </main>
    </div>
    
    <script src="../assets/js/main.js"></script>
</body>
</html>